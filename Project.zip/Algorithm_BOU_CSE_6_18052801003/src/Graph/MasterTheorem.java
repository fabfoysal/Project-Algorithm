///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package Graph;
//
///**
// *
// * @author Imran
// */
//public class MasterTheorem {
//    
//}
//Master Method
//The Master Method is used for solving the following types of recurrence
//
//T (n) = a TDAA Master Method+ f (n) with a≥1 and b≥1 be constant & f(n) be a function and DAA Master Methodcan be interpreted as
//
//Let T (n) is defined on non-negative integers by the recurrence.
//
// T (n) = a TDAA Master Method+ f (n)
//In the function to the analysis of a recursive algorithm, the constants and function take on the following significance:
//
//n is the size of the problem.
//a is the number of subproblems in the recursion.
//n/b is the size of each subproblem. (Here it is assumed that all subproblems are essentially the same size.)
//f (n) is the sum of the work done outside the recursive calls, which includes the sum of dividing the problem and the sum of combining the solutions to the subproblems.
//It is not possible always bound the function according to the requirement, so we make three cases which will tell us what kind of bound we can apply on the function.
//Master Theorem:
//It is possible to complete an asymptotic tight bound in these three cases:
//
//DAA Master Method
//Case1: If f (n) = DAA Master Method for some constant ε >0, then it follows that:
//
//T (n) = Θ DAA Master Method
//Example:
//
//T (n) = 8 T DAA Master Method apply master theorem on it.
//Solution:
//
//Compare T (n) = 8 T DAA Master Method with 
// T (n) = a T DAA Master Method
// a = 8, b=2, f (n) = 1000 n2, logba = log28 = 3
// Put all the values in: f (n) = DAA Master Method
//     1000 n2 = O (n3-ε ) 
//     If we choose ε=1, we get: 1000 n2 = O (n3-1) = O (n2)
//Since this equation holds, the first case of the master theorem applies to the given recurrence relation, thus resulting in the conclusion:
//
//T (n) = Θ DAA Master Method
//   Therefore: T (n) = Θ (n3) 
//Case 2: If it is true, for some constant k ≥ 0 that:
//
//F (n) = Θ DAA Master Method then it follows that: T (n) = Θ DAA Master Method
//Example:
//
//T (n) = 2 DAA Master Method, solve the recurrence by using the master method.
//As compare the given problem with T (n) = a TDAA Master Method a = 2, b=2, k=0, f (n) = 10n, logba = log22 =1 
//Put all the values in f (n) =Θ DAA Master Method, we will get 
//	10n = Θ (n1) = Θ (n) which is true.
//Therefore: T (n) = Θ DAA Master Method
//      = Θ (n log n)
//Case 3: If it is true f(n) = Ω DAA Master Method for some constant ε >0 and it also true that: a f DAA Master Method for some constant c<1 for large value of n ,then :
//
//T (n) = Θ((f (n))   
//Example: Solve the recurrence relation:
//
//T (n) = 2 DAA Master Method
//Solution:
//
//Compare the given problem with T (n) = a T DAA Master Method
//a= 2, b =2, f (n) = n2, logba = log22 =1 
//Put all the values in f (n) = Ω DAA Master Method ..... (Eq. 1)
//If we insert all the value in (Eq.1), we will get 
//  n2 = Ω(n1+ε) put ε =1, then the equality will hold.
//  n2 = Ω(n1+1) = Ω(n2)
//Now we will also check the second condition:
//  2 DAA Master Method
//If we will choose c =1/2, it is true:
//  DAA Master Method  ∀ n ≥1 
//So it follows: T (n) = Θ ((f (n))
//    T (n) = Θ(n2)

/////////////////////////////////////////////////////////////////////////////////

//Master Theorem
//In this tutorial, you will learn what master theorem is and how it is used for solving recurrence relations.
//
//The master method is a formula for solving recurrence relations of the form:
//
//T(n) = aT(n/b) + f(n),
//where,
//n = size of input
//a = number of subproblems in the recursion
//n/b = size of each subproblem. All subproblems are assumed 
//     to have the same size.
//f(n) = cost of the work done outside the recursive call, 
//      which includes the cost of dividing the problem and
//      cost of merging the solutions
//
//Here, a ≥ 1 and b > 1 are constants, and f(n) is an asymptotically positive function.
//An asymptotically positive function means that for a sufficiently large value of n, we have f(n) > 0.
//
//The master theorem is used in calculating the time complexity of recurrence relations (divide and conquer algorithms) in a simple and quick way.
//
//Master Theorem
//If a ≥ 1 and b > 1 are constants and f(n) is an asymptotically positive function, then the time complexity of a recursive relation is given by
//
//T(n) = aT(n/b) + f(n)
//
//where, T(n) has the following asymptotic bounds:
//
//    1. If f(n) = O(nlogb a-ϵ), then T(n) = Θ(nlogb a).
//
//    2. If f(n) = Θ(nlogb a), then T(n) = Θ(nlogb a * log n).
//
//    3. If f(n) = Ω(nlogb a+ϵ), then T(n) = Θ(f(n)).
//
//ϵ > 0 is a constant.
//Each of the above conditions can be interpreted as:
//
//If the cost of solving the sub-problems at each level increases by a certain factor, the value of f(n) will become polynomially smaller than nlogb a. Thus, the time complexity is oppressed by the cost of the last level ie. nlogb a
//If the cost of solving the sub-problem at each level is nearly equal, then the value of f(n) will be nlogb a. Thus, the time complexity will be f(n) times the total number of levels ie. nlogb a * log n
//If the cost of solving the subproblems at each level decreases by a certain factor, the value of f(n) will become polynomially larger than nlogb a. Thus, the time complexity is oppressed by the cost of f(n).


//Solved Example of Master Theorem
//T(n) = 3T(n/2) + n2
//Here,
//a = 3
//n/b = n/2
//f(n) = n2
//
//logb a = log2 3 ≈ 1.58 < 2
//
//ie. f(n) < nlogb a+ϵ , where, ϵ is a constant.
//
//Case 3 implies here.
//
//Thus, T(n) = f(n) = Θ(n2) 



//Master Theorem Limitations
//The master theorem cannot be used if:
//
//T(n) is not monotone. eg. T(n) = sin n
//f(n) is not a polynomial. eg. f(n) = 2n
//a is not a constant. eg. a = 2n
//a < 1