/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graph;

/**
 *
 * @author Imran
 */
public class Knapsack_DynamicBasedSolution {
    // A Dynamic Programming based solution
// for 0-1 Knapsack problem

 
    // A utility function that returns
    // maximum of two integers
    static int max(int a, int b)
    {
          return (a > b) ? a : b;
    }
 
    // Returns the maximum value that can
    // be put in a knapsack of capacity W
    static int knapSack(int W, int wt[],
                        int val[], int n)
    {
        int i, w;
        int K[][] = new int[n + 1][W + 1];
 
        // Build table K[][] in bottom up manner
        for (i = 0; i <= n; i++)
        {
            for (w = 0; w <= W; w++)
            {
                if (i == 0 || w == 0)
                    K[i][w] = 0;
                else if (wt[i - 1] <= w)
                    K[i][w]
                        = max(val[i - 1]
                         + K[i - 1][w - wt[i - 1]],
                         K[i - 1][w]);
                else
                    K[i][w] = K[i - 1][w];
            }
        }
 
        return K[n][W];
    }
 
    // Driver code
    public static void main(String args[])
    {
        int val[] = new int[] { 60, 100, 120 };
        int wt[] = new int[] { 10, 20, 30 };
        int W = 50;
        int n = val.length;
        System.out.println(knapSack(W, wt, val, n));
    }
}
/*This code is contributed by Rajat Mishra */

/////////////////////////////////////////////////////////////////////////////
// we can further improve the above Knapsack function's space
  // complexity
//  static int knapSack(int W, int wt[], int val[], int n)
//  {
//    int i, w;
//    int [][]K = new int[2][W + 1];
//     
//    // We know we are always using the current row or
//    // the previous row of the array/vector . Thereby we can
//    // improve it further by using a 2D array but with only
//    // 2 rows i%2 will be giving the index inside the bounds
//    // of 2d array K
//    for (i = 0; i <= n; i++) {
//      for (w = 0; w <= W; w++) {
//        if (i == 0 || w == 0)
//          K[i % 2][w] = 0;
//        else if (wt[i - 1] <= w)
//          K[i % 2][w] = Math.max(
//          val[i - 1]
//          + K[(i - 1) % 2][w - wt[i - 1]],
//          K[(i - 1) % 2][w]);
//        else
//          K[i % 2][w] = K[(i - 1) % 2][w];
//      }
//    }
//    return K[n % 2][W];
//  }
// 
//  // Driver Code
//  public static void main(String[] args)
//  {
//    int val[] = { 60, 100, 120 };
//    int wt[] = { 10, 20, 30 };
//    int W = 50;
//    int n = val.length;
// 
//    System.out.print(knapSack(W, wt, val, n));
// 
//  }
//}
 
// This code is contributed by gauravrajput1

/////////////////////////////////////////////////////////////////////////////
//Scope for Improvement :-  We used the same approach but with optimized space complexity
//
//import java.util.*;
//class GFG {
// 
//  // we can further improve the above Knapsack function's space
//  // complexity
//  static int knapSack(int W, int wt[], int val[], int n)
//  {
//    int i, w;
//    int [][]K = new int[2][W + 1];
//     
//    // We know we are always using the current row or
//    // the previous row of the array/vector . Thereby we can
//    // improve it further by using a 2D array but with only
//    // 2 rows i%2 will be giving the index inside the bounds
//    // of 2d array K
//    for (i = 0; i <= n; i++) {
//      for (w = 0; w <= W; w++) {
//        if (i == 0 || w == 0)
//          K[i % 2][w] = 0;
//        else if (wt[i - 1] <= w)
//          K[i % 2][w] = Math.max(
//          val[i - 1]
//          + K[(i - 1) % 2][w - wt[i - 1]],
//          K[(i - 1) % 2][w]);
//        else
//          K[i % 2][w] = K[(i - 1) % 2][w];
//      }
//    }
//    return K[n % 2][W];
//  }
// 
//  // Driver Code
//  public static void main(String[] args)
//  {
//    int val[] = { 60, 100, 120 };
//    int wt[] = { 10, 20, 30 };
//    int W = 50;
//    int n = val.length;
// 
//    System.out.print(knapSack(W, wt, val, n));
// 
//  }
//}
// 
//// This code is contributed by gauravrajput1
//Complexity Analysis:
//
//Time Complexity: O(N*W).
//Auxiliary Space: O(2*W) 
//As we are using a 2-D array but with only 2 rows.
//Method 3: This method uses Memoization Technique (an extension of recursive approach).
//This method is basically an extension to the recursive approach so that we can overcome the problem of calculating redundant cases and thus increased complexity. We can solve this problem by simply creating a 2-D array that can store a particular state (n, w) if we get it the first time. Now if we come across the same state (n, w) again instead of calculating it in exponential complexity we can directly return its result stored in the table in constant time. This method gives an edge over the recursive approach in this aspect.
//
//
//// Here is the top-down approach of 
//// dynamic programming
//class GFG{
//     
//// A utility function that returns 
//// maximum of two integers    
//static int max(int a, int b)    
//{    
//    return (a > b) ? a : b;    
//}
// 
//// Returns the value of maximum profit  
//static int knapSackRec(int W, int wt[],
//                       int val[], int n,
//                       int [][]dp)
//{  
//     
//    // Base condition
//    if (n == 0 || W == 0)  
//        return 0;
//         
//    if (dp[n][W] != -1)
//        return dp[n][W];  
//     
//    if (wt[n - 1] > W)  
//     
//        // Store the value of function call  
//        // stack in table before return
//        return dp[n][W] = knapSackRec(W, wt, val,
//                                      n - 1, dp);
//                                       
//    else
//     
//        // Return value of table after storing 
//        return dp[n][W] = max((val[n - 1] +
//                              knapSackRec(W - wt[n - 1], wt,
//                                          val, n - 1, dp)),
//                              knapSackRec(W, wt, val,
//                                          n - 1, dp));            
//}
// 
//static int knapSack(int W, int wt[], int val[], int N)
//{ 
//     
//    // Declare the table dynamically
//    int dp[][] = new int[N + 1][W + 1];
//     
//    // Loop to initially filled the
//    // table with -1
//    for(int i = 0; i < N + 1; i++)  
//        for(int j = 0; j < W + 1; j++)  
//            dp[i][j] = -1;   
//     
//    return knapSackRec(W, wt, val, N, dp);    
//}
// 
//// Driver Code
//public static void main(String [] args)
//{      
//    int val[] = { 60, 100, 120 };  
//    int wt[] = { 10, 20, 30 };  
//     
//    int W = 50; 
//    int N = val.length;        
//     
//    System.out.println(knapSack(W, wt, val, N));  
//}    
//}
// 
//// This Code is contributed By FARAZ AHMAD
//Output
//220
//Complexity Analysis: 
//
//Time Complexity: O(N*W). 
//As redundant calculations of states are avoided.
//Auxiliary Space: O(N*W). 
//The use of 2D array data structure for storing intermediate states-:
//[Note: For 32bit integer use long instead of int.]
//References: 
//
//http://www.es.ele.tue.nl/education/5MC10/Solutions/knapsack.pdf
//http://www.cse.unl.edu/~goddard/Courses/CSCE310J/Lectures/Lecture8-DynamicProgramming.pdf
//https://youtu.be/T4bY72lCQac?list=PLqM7alHXFySGMu2CSdW_6d2u1o6WFTIO-
// 
//Please write comments if you find anything incorrect, or you want to share more information about the topic discussed above.
//
//Method 4 :-  Again we use the dynamic programming approach with even more optimized space complexity .
//
//
//import java.util.*;
// 
//class GFG{
//  static int knapSack(int W, int wt[], int val[], int n)
//  {
//    // making and initializing dp array
//    int []dp = new int[W + 1];
// 
// 
//    for (int i = 1; i < n + 1; i++) {
//      for (int w = W; w >= 0; w--) {
// 
//        if (wt[i - 1] <= w)
//           
//          // finding the maximum value
//          dp[w] = Math.max(dp[w],
//                           dp[w - wt[i - 1]] + val[i - 1]);
//      }
//    }
//    return dp[W]; // returning the maximum value of knapsack
//  }
//   
//  // Driver code
//  public static void main(String[] args)
//  {
//    int val[] = { 60, 100, 120 };
//    int wt[] = { 10, 20, 30 };
//    int W = 50;
//    int n = val.length;
//    System.out.print(knapSack(W, wt, val, n));
//  }
//}
// 
//// This code is contributed by gauravrajput1
//Output
//220
//Complexity Analysis:
//
//Time Complexity: O(N*W). As redundant calculations of states are avoided.
//
//Auxiliary Space: O(W) As we are using 1-D array instead of 2-D array.

///////////////////////////////////////////////////////////////////////////
//class Main
//{
//    // Values (stored in array `v`)
//    // Weights (stored in array `w`)
//    // Total number of distinct items `n`
//    // Knapsack capacity `W`
//    public static int knapsack(int[] v, int[] w, int n, int W)
//    {
//        // base case: Negative capacity
//        if (W < 0) {
//            return Integer.MIN_VALUE;
//        }
// 
//        // base case: no items left or capacity becomes 0
//        if (n < 0 || W == 0) {
//            return 0;
//        }
// 
//        // Case 1. Include current item `v[n]` in the knapsack and recur for
//        // remaining items `n-1` with decreased capacity `W-w[n]`
// 
//        int include = v[n] + knapsack(v, w, n - 1, W - w[n]);
// 
//        // Case 2. Exclude current item `v[n]` from the knapsack and recur for
//        // remaining items `n-1`
// 
//        int exclude = knapsack(v, w, n - 1, W);
// 
//        // return maximum value we get by including or excluding the current item
//        return Integer.max(include, exclude);
//    }
// 
//    // 0–1 Knapsack problem
//    public static void main(String[] args)
//    {
//        // input: a set of items, each with a weight and a value
//        int[] v = { 20, 5, 10, 40, 15, 25 };
//        int[] w = { 1, 2, 3, 8, 7, 4 };
// 
//        // knapsack capacity
//        int W = 10;
// 
//        System.out.println("Knapsack value is " +
//                knapsack(v, w, v.length - 1, W));
//    }
//}
//Download  Run Code
//
//Output:
//
//Knapsack value is 60
//
//The time complexity of the above solution is exponential and occupies space in the call stack.
// 
//
// 
//The above solution has an optimal substructure, i.e., the optimal solution can be constructed efficiently from optimal solutions of its subproblem. It also has overlapping subproblems, i.e., the problem can be broken down into subproblems, and each subproblem is repeated several times. To reuse the subproblem solutions, we can apply dynamic programming, in which subproblem solutions are memoized rather than computed over and over again.
//
//Following is the memoized version in C++, Java, and Python, which follows the top-down approach since we first break the problem into subproblems and then calculate and store values.
//
//
//import java.util.HashMap;
//import java.util.Map;
// 
//class Main
//{
//    // Values (stored in array `v`)
//    // Weights (stored in array `w`)
//    // Total number of distinct items `n`
//    // Knapsack capacity `W`
//    public static int knapsack(int[] v, int[] w, int n, int W,
//                            Map<String, Integer> lookup)
//    {
//        // base case: Negative capacity
//        if (W < 0) {
//            return Integer.MIN_VALUE;
//        }
// 
//        // base case: no items left or capacity becomes 0
//        if (n < 0 || W == 0) {
//            return 0;
//        }
// 
//        // construct a unique map key from dynamic elements of the input
//        String key = n + "|" + W;
// 
//        // if the subproblem is seen for the first time, solve it and
//        // store its result in a map
//        if (!lookup.containsKey(key))
//        {
//            // Case 1. Include current item `n` in knapsack (v[n]) and recur
//            // for remaining items `n-1` with decreased capacity `W-w[n]`
//            int include = v[n] + knapsack(v, w, n - 1, W - w[n], lookup);
// 
//            // Case 2. Exclude current item `v[n]` from the knapsack and recur for
//            // remaining items `n-1`
//            int exclude = knapsack(v, w, n - 1, W, lookup);
// 
//            // assign the max value we get by including or excluding the current item
//            lookup.put(key, Integer.max(include, exclude));
//        }
// 
//        // return solution to the current subproblem
//        return lookup.get(key);
//    }
// 
//    // 0–1 Knapsack problem
//    public static void main(String[] args)
//    {
//        // input: a set of items, each with a weight and a value
//        int[] v = { 20, 5, 10, 40, 15, 25 };
//        int[] w = { 1, 2, 3, 8, 7, 4 };
// 
//        // knapsack capacity
//        int W = 10;
// 
//        // create a map to store solutions to a subproblem
//        Map<String, Integer> lookup = new HashMap<>();
// 
//        System.out.println("Knapsack value is " +
//                knapsack(v, w, v.length - 1, W, lookup));
//    }
//}
//Download  Run Code
//
//Output:
//
//Knapsack value is 60
//
//The time complexity of the above top-down solution is O(n.W) and requires O(n.W) extra space, where n is the total number of items in the input and W is the knapsack’s capacity.
// 
//
// 
//We can also solve this problem in a bottom-up manner. In the bottom-up approach, we solve smaller subproblems first, then solve larger subproblems from them. The following bottom-up approach computes T[i][j], for each 1 <= i <= n and 0 <= j <= W, which is the maximum value that can be attained with weight less than or equal to j and using items up to first i items. It uses the value of smaller values i and j already computed. It has the same asymptotic runtime as Memoization but no recursion overhead.
//
//The algorithm can be implemented as follows in C++, Java, and Python:
//
//
//class Main
//{
//    // Input:
//    // Values (stored in array `v`)
//    // Weights (stored in array `w`)
//    // Total number of distinct items `n`
//    // Knapsack capacity `W`
//    public static int knapsack(int[] v, int[] w, int W)
//    {
//        // `T[i][j]` stores the maximum value of knapsack having weight
//        // less than equal to `j` with only first `i` items considered.
//        int[][] T = new int[v.length + 1][W + 1];
// 
//        // do for i'th item
//        for (int i = 1; i <= v.length; i++)
//        {
//            // consider all weights from 0 to maximum capacity `W`
//            for (int j = 0; j <= W; j++)
//            {
//                // don't include the i'th element if `j-w[i-1]` is negative
//                if (w[i-1] > j) {
//                    T[i][j] = T[i-1][j];
//                }
//                else {
//                    // find the maximum value we get by excluding or including
//                    // the i'th item
//                    T[i][j] = Integer.max(T[i-1][j], T[i-1][j-w[i-1]] + v[i-1]);
//                }
//            }
//        }
// 
//        // return maximum value
//        return T[v.length][W];
//    }
// 
//    public static void main(String[] args)
//    {
//        // input: a set of items, each with a weight and a value
//        int[] v = { 20, 5, 10, 40, 15, 25 };
//        int[] w = { 1, 2, 3, 8, 7, 4 };
// 
//        // knapsack capacity
//        int W = 10;
// 
//        System.out.println("Knapsack value is " + knapsack(v, w, W));
//    }
//}
//Download  Run Code
//
//Output:
//
//Knapsack value is 60
/////////////////////////////////////////////////////////////////////////////