
// Linked list implementation in Java
package DataStructure;
class LinkedList {
  // Creating a node
  Node head;

  static class Node {
    int value;
    Node next;

    Node(int d) {
      value = d;
      next = null;
    }
  }

  public static void main(String[] args) {
    LinkedList linkedList = new LinkedList();

    // Assign value values
    linkedList.head = new Node(1);
    Node second = new Node(2);
    Node third = new Node(3);

    // Connect nodess
    linkedList.head.next = second;
    second.next = third;

    // printing node-value
    while (linkedList.head != null) {
      System.out.print(linkedList.head.value + " ");
      linkedList.head = linkedList.head.next;
    }
  }
}
////////////////////////////////////////////////////////////////////////////////
//package DataStructure;
//
//import java.util.*;
////import static javax.management.Query.gt;
//public class Linked_List {
////    
////
////       public static void main(String[] args) {
////        //create a LinkedList object and initialize it with Array elements converted to list
////            LinkedList&lt;
////            Integer&gt; 
////            intList = new LinkedList&lt;&gt;
////            (Arrays.asList(10,20,30,40,50));
////            //print the LinkedList just created
////            System.out.println("Contents of first LinkedList: " + intList);
////         
////            //create an empty list
////            LinkedList&lt;String&gt; colorsList = new LinkedList&lt;&gt;();
////            //add elements to the linkedList using add method.
////            colorsList.add("Red");
////         colorsList.add("Green");
////            colorsList.add("Blue");
////            colorsList.add("Cyan");
////            colorsList.add("Magenta");
////            // print the LinkedList
////            System.out.println("\nContents of second LinkedList: " + colorsList);
////    }
////}
////
//////////////////////////////////////////////////////////////////////////////////
//
////import java.util.*; 
//   
////public class Main { 
//    
//    
//    public static void main(String args[])  { 
//        //create a linked list 
//        LinkedList&lt;String&gt; l_list = new LinkedList&lt;String&gt;(); 
//   
//        // Add elements to linkedList using various add methods
//        l_list.add("B"); 
//        l_list.add("C"); 
//        l_list.addLast("G"); 
//        l_list.addFirst("A"); 
//        l_list.add(3, "D"); 
//        l_list.add("E"); 
//        l_list.add("F"); 
//        //print the linkedList
//        System.out.println("Linked list : " + l_list);
//         
//        //Create and initialize an ArrayList
//        ArrayList&lt;String&gt; aList = new ArrayList&lt;&gt;();
//        aList.add("H");
//        aList.add("I");
//        //add the ArrayList to linkedList using addAll method
//        l_list.addAll(aList);
//        //print the linkedList
//        System.out.println("Linked list after adding ArrayList contents: " + l_list);
//   
//        // use various remove methods to remove elements from linkedList
//        l_list.remove("B"); 
//        l_list.remove(3); 
//        l_list.removeFirst(); 
//        l_list.removeLast(); 
//        //print the altered list
//        System.out.println("Linked list after deletion: " + l_list); 
// 
//// use contains method to check for an element in the linkedList
//        boolean ret_value = l_list.contains("G"); 
//        //print the results of contains method
//        if(ret_value) 
//            System.out.println("List contains the element 'G' "); 
//        else
//            System.out.println("List doesn't contain the element 'G'"); 
//   
//        // use size methods to return Number of elements in the linked list 
//        int size = l_list.size(); 
//        System.out.println("Size of linked list = " + size); 
//   
//        // Get and set elements from linked list 
//        Object element = l_list.get(3); 
//        System.out.println("Element returned by get() : " + element); 
//        l_list.set(3, "J"); 
//        System.out.println("Linked list after change : " + l_list); 
//         
//        //convert linkedList to Array using toArray methods
//        String [] list_array = l_list.toArray(new String[l_list.size()]);
//         
//        System.out.println("Array obtained from linked List:" +
//            Arrays.toString(list_array));
//         
//    } 
//}
//////////////////////////////////////////////////////////////////////////
//
///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package DataStructure;
//
///**
// *
// * @author Imran
// */
//public class Linked_List_By_Collection_Sort {
//    The below Java program sorts a LinkedList using Collections.sort (). Here we sort arrays using natural ordering as well as using a comparator.
//
//import java.util.*;
//public class Main{
//public static void main(String args[]) {
//    // create and initialize the LinkedList object
//    LinkedList&lt;String&gt; l_list = new LinkedList&lt;&gt;();
//    l_list.add("Jan");
//    l_list.add("Feb");
//    l_list.add("Mar");
//    l_list.add("Apr");
//    l_list.add("May");
//    l_list.add("Jun");
//    //print original unsorted linkedlist
//    System.out.println("Original LinkedList (unsorted): " + l_list);
//    // sort LinkedList with Collecitons.sort() method in natural order
//    Collections.sort(l_list);
//    System.out.println("\nLinkedList (sorted in natural order): " + l_list);
//    // sort LinkedList using Collection.sort() and Comparator in Java
//    Collections.sort(l_list, new Comparator&lt;String&gt;() {
//    @Override
//    public int compare(String s1, String s2) {
//        return s1.length() - s2.length();
//    } } );
// 
//    System.out.println("LinkedList (sorted using Comparator): " + l_list);
//    }
//}
//}
////////////////////////////////////////////////////////////////////////////////
///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package DataStructure;
//import java.util.LinkedList;
///**
// *
// * @author Imran
// */
//public class Linked_List_By_Loop {
//    
//    public static void main(String[] args) {
//        // Create a LinkedList and initialize it
//        LinkedList&lt;String&gt; colorList = new LinkedList&lt;&gt;();
//        colorList.add("Red");
//        colorList.add("Green");
//        colorList.add("Blue");
//         
//        // Using for loop,print the contents of the LinkedList
//        System.out.println("LinkedList elements using for loop:");
//        for(int i=0; i &lt; colorList.size(); i++) {
//            System.out.print(colorList.get(i) + " ");
//        }
//    }
//}
//
/////////////////////////////////////////////////////////////////////
///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package DataStructure;
//
///**
// *
// * @author Imran
// */
//public class Linked_List_Manipulate {
//    class CircularLinkedList {  
//    //Node definition for circular linked list  
//    public class Node{  
//        int data;  
//        Node next;  
//        public Node(int data) {  
//            this.data = data;  
//        }  
//    }    
//    //Initially head and tail pointers point to null  
//    public Node head = null;  
//    public Node tail = null;  
//    //add new node to the circular linked list   
//    public void add(int data){  
//        //Create new node  
//        Node newNode = new Node(data);  
//        //check if list is empty  
//        if(head == null) {  
//             //head and tail point to same node if list is empty  
//            head = newNode;  
//            tail = newNode;  
//            newNode.next = head;  
//        }  
//        else {  
//            //tail points to new node if list is not empty
//            tail.next = newNode;  
//            //New node becomes new tail.  
//            tail = newNode;  
//            //tail points back to head  
//            tail.next = head;  
//        }  
//    }  
//    //Display the nodes in circular linked list 
//    public void displayList() {  
//        Node current = head;  
//        if(head == null) {  
//            System.out.println("The List is empty");  
//        }  
//        else {  
//            System.out.println("Circular linked list nodes: ");  
//             do{  
//                //Print each node of the linked list  
//                System.out.print(current.data + " ");  
//                current = current.next;  
//            }while(current != head);  
//            System.out.println();  
//        }  
//    }  
//}
//class Main{
//    public static void main(String[] args) {  
//        //create a CircularLinkedList object
//        CircularLinkedList c_list = new CircularLinkedList();  
//        //Add data to the list  
//        c_list.add(10);  
//        c_list.add(20);  
//        c_list.add(30);  
//        c_list.add(40);  
//        //Display the nodes in circular linked list 
//        c_list.displayList();  
//    }  
//}  
//}
////////////////////////////////////////////////////////////////////
///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package DataStructure;
//
///**
// *
// * @author Imran
// */
//public class Linked_List_Remove_Duplicate {
//    class LinkedList_Duplicate {    
//    //A class to represent node in linkedlist 
//    class Node{  
//        int data;  
//        Node next;  
//        public Node(int data) {  
//            this.data = data;  
//            this.next = null;  
//        }  
//    }  
//    //Initially the head and tail of the linked list set to null  
//    public Node head = null;  
//    public Node tail = null;  
//    //add a new node to the linkedlist  
//    public void addNode(int data) {  
//        //Create new node 
//        Node newNode = new Node(data);  
//   
//        //If list is empty set head and tail to new node  
//        if(head == null) {  
//            head = newNode;  
//            tail = newNode;  
//        }  
//        else {  
//            // add newNode after the tail
//            tail.next = newNode;  
//            //newNode is now the tail or last element  
//            tail = newNode;  
//        }  
//    }  
// 
////scans the linkedlist and removes duplicate nodes 
//    public void removeDuplicateNodes() {  
//        //Head is the current node  
//        Node current = head, index = null, temp = null;  
//        //head = null means list is empty
//        if(head == null) {  
//            return;  
//        }  
//        //traverse through the list
//        else {  
//            while(current != null){  
//                //temp node points to previous node to index.  
//                temp = current;  
//                //Index will point to node next to current  
//                index = current.next;  
//                  while(index != null) {  
//                    //Check if current node's data is equal to index node's data  
//                    if(current.data == index.data) {  
//                        //since node is duplicate skip index and point to next node 
//                        temp.next = index.next;  
//                    }  
//                    else {  
//                        //Temp will point to previous node of index.  
//                        temp = index;  
//                    }  
//                    index = index.next;  
//                }  
//                current = current.next;  
//            }  
//        }  
//    }  
//  //print the linked list  
//    public void print() {  
//        //Node current will point to head  
//        Node current = head;  
//        if(head == null) {  
//            System.out.println("List is empty");  
//            return;  
//        }  
//        while(current != null) {  
//            //Print each node by incrementing pointer  
//            System.out.print(current.data + " ");  
//            current = current.next;  
//        }  
//        System.out.println();  
//    }  
//}class Main{
//    public static void main(String[] args) {  
//        LinkedList_Duplicate l_List = new LinkedList_Duplicate();  
//   
//        //Add data to the list  
//        l_List.addNode(1);  
//        l_List.addNode(1);  
//        l_List.addNode(2);  
//        l_List.addNode(3);  
//        l_List.addNode(5);  
//        l_List.addNode(2);  
//        l_List.addNode(1);
//        l_List.addNode(1);
//        //print the original list
//        System.out.println("Original Linkedlist: ");  
//        l_List.print();  
//         
//        //Removes duplicate nodes  
//        l_List.removeDuplicateNodes();  
//        //print the altered list without duplicates  
//        System.out.println("LinkedList after removing duplicates: ");  
//        l_List.print();  
//    }  
//}  
//}
//
///////////////////////////////////////////////////////////////////////
//
//package DataStructure;
//
//
//   // The below program reverses the linked list using the descendingIterator () method.
//
//import java.util.*; 
//              
//         
//public class Main{  
// public static void main(String args[]){  
//    //create a LinkedList object
//    LinkedList&lt;String&gt; l_list=new LinkedList&lt;String&gt;();  
//    l_list.add("Pune");  
//    l_list.add("Mumbai");  
//    l_list.add("Nagpur");  
//    System.out.println("Linked List : " + l_list);
//    System.out.println("Linked List in reverse order:");
//    //use descendingIterator method to get a reverse iterator
//    Iterator iter=l_list.descendingIterator();  
//    //traverse the list using iterator and print the elements.
//    while(iter.hasNext())  
//    {  
//        System.out.print(iter.next() + " ");  
//    }  
// }  
//}  
//
//////////////////////////////////////////////////////////////////////////////
///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package DataStructure;
// import java.util.*; 
///**
// *
// * @author Imran
// */
//public class Linked_List_By_Iterator {
//   
//  
////public class Main{  
// public static void main(String args[]){  
//  //declare a LinkedList object
//  LinkedList&lt;String&gt; l_list=new LinkedList&lt;String&gt;();  
//  //Add elements to LinkedList
//  l_list.add("Red");  
//  l_list.add("Green");  
//  l_list.add("Blue");  
//  l_list.add("Yellow");  
//  //declare an iterator for the LinkedList
//  Iterator&lt;String&gt; itr=l_list.iterator();  
//  System.out.println("The contents of Linked List:");
//  //Iterate through the LinkedList using Iterator and print its elements
//    while(itr.hasNext()){  
//        System.out.print(itr.next() + " ");  
//    }  
// }  
//} 
//
////////////////////////////////////////////////////////////////////////
///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package DataStructure;
//
///**
// *
// * @author Imran
// */
//public class Linked_List_Stream_to_Display {
//    import java.util.LinkedList;
//import java.util.List;
// 
//public class Main {
//  public static void main(String[] args) 
//  { 
//    //create a LinkedList and initialize it to values
//    List&lt;String&gt; colorsList = new LinkedList&lt;&gt;();
//    colorsList.add("Red");
//    colorsList.add("Green");
//    colorsList.add("Blue");
//    colorsList.add("Cyan");
//    colorsList.add("Magenta");
//         
//    //convert List to stream &amp; print it
//    System.out.println("The contents of LinkedList:");
//    colorsList.stream().forEach(System.out::println);
//  }
//}
//
//}
//
//
//
///////////////////////////////////////////////////////////////////////
