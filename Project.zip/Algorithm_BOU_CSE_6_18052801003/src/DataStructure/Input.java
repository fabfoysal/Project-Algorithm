
package DataStructure;
import java.util.Scanner;

public class Input {
    Scanner input = new Scanner(System.in);
     
    public int[] sort_input() 
    {
        System.out.println("Enter the number of integers");
        int num = input.nextInt();
        System.out.println("Enter : " + num + " integers : ");
        
        
        int arr[] = new int[num];
        for (int i = 1; i <= num; i++) 
        {
            System.out.println("Enter "+(i)+" Number [");
            arr[i-1] = input.nextInt();
        }
        return arr;
    }
}
